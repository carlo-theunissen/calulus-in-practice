﻿namespace Logic.interfaces
{
    public interface IArgumentController
    {
        bool SetArgumentValue(char name, bool? value);
    }
}