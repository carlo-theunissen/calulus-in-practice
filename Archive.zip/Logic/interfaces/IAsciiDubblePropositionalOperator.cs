﻿namespace Logic.interfaces
{
    public interface IAsciiDubblePropositionalOperator : IAsciiSinglePropositionalOperator
    {
    }
}