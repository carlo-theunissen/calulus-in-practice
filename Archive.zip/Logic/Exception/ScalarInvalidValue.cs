﻿namespace Logic.Exception
{
    public class ScalarInvalidValue : System.Exception
    {
    }
}