**Proposition Logic**

https://portal.fhict.nl/av/_layouts/15/WopiFrame.aspx?sourcedoc=/av/Lesmateriaal%20Logic/ALE1_LabManual.docx&action=default